tests
=====

This is not yet a real test suite. I'm just putting here some executables I use as quick and dirty checks.
Don't expect too much from them =)